//#include "student_info.h"

void display_file(char *fileName);
void search_content(char *fileName, int mis);
void delete_content(char *fileName, int mis);
void insert(char *fileName,stud s);
void update_content(char *fileName, int mis);
